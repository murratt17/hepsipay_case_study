import { Page } from "@playwright/test";
import { CheckOutPage } from "./checkout-page";
import { ListingPage } from "./listing-page";
import { ProductDetailPage } from "./product_detail-page";
import { LoginPage } from "./login-page";
import { SearchPage } from "./search-page";





export class Play {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    public get searchPage(): SearchPage {
      return new SearchPage(this.page);
    }
  
    public get checkOutPage(): CheckOutPage {
      return new CheckOutPage(this.page);
    }
  
    public get listingPage(): ListingPage {
      return new ListingPage(this.page);
    }

    public get productDetailPage() :ProductDetailPage{
        return new ProductDetailPage(this.page)
    }

    public get loginPage() :LoginPage{
      return new LoginPage(this.page)
  }
  }