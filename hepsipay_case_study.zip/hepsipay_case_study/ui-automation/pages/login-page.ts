import { Page } from "@playwright/test";

export class LoginPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    username = this.page.locator('#txtUserName')
    password = this.page.locator("(//input[@id='txtPassword'])[1]")
    btnLogin = this.page.locator("//button[text()='Giriş yap']")


        
  }