import { Page } from "@playwright/test";

export class ListingPage {
    constructor(protected page: Page) {
      this.page = page;
    }
      

    firstProduct = this.page.locator('(//li[@type="comfort"])[1]');

    

  }