import { Page } from "@playwright/test";

export class CheckOutPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    productName = this.page.locator('//div[@class="product_name_2Klj3"]')
    offeringPrice = this.page.locator('//div[@class="product_price_uXU6Q"]')
    continueButton = this.page.locator('#continue_step_btn')
    otherPaymentOptions = this.page.locator("//a[contains(text(),'Diğer ödeme seçenekleri')]")
    instantPayment = this.page.locator("//div[text()='Anında havale']")

  }