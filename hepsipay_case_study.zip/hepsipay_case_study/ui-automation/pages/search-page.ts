import { Page } from "@playwright/test";

export class SearchPage {
    constructor(protected page: Page) {
      this.page = page;
    }
  
    searchClickArea = this.page.locator('div').filter({ hasText: /^Ürün, kategori veya marka ara$/ }).first()
    searchBox = this.page.getByPlaceholder('Ürün, kategori veya marka ara');
    searchButton = this.page.getByText('ARA', { exact: true });
    loginBtn = this.page.locator("//span[text()='Giriş Yap']")
    lblLogin = this.page.locator("//a[@title='Giriş yap']")


  }