import { test, expect } from '@playwright/test';

import { Play } from "../pages/play";



test('hepsiburada', async ({ page }) => {
 
  const play = new Play(page);

  await page.goto('/');                                                                     //navigates to www.hepsiburada.com

  await play.searchPage.searchClickArea.click();
  await play.searchPage.searchBox.fill("kitap");                              //types 
  await play.searchPage.searchButton.click();                                             
  expect(page.url()).toContain("kitap")                                                 //checks the url if it contains bluetooth
  await play.listingPage.firstProduct.click();                                              //chooses the first product
  await page.waitForTimeout(3000);  
  const openTabs = await page.context().pages()
  await page.goto(openTabs[1].url().toString())
  await openTabs[1].close();                                                                //closes the secondary tab

  const nameOfProductInProductDetailPage = await play.productDetailPage.productName.innerText();   //assigns the productname in product detail page
  const offeringPriceInProductDetailPage = await play.productDetailPage.offeringPrice.innerText(); //assigns the offeringPrice in product detail page

  await play.productDetailPage.addToChart.click();                                          //clicks addToChart
  await play.productDetailPage.goToChart.click();                                           //navigates to Chart
  await expect(page).toHaveURL('https://checkout.hepsiburada.com');

  const nameOfProductInCheckOutPage = await play.checkOutPage.productName.innerText();      //assigns the productname in checkoutPage
  const offeringPriceInCheckOutPage = await play.checkOutPage.offeringPrice.innerText();    //assigns the offeringPrice in checkoutPage

  expect(nameOfProductInProductDetailPage).toEqual(nameOfProductInCheckOutPage);            //compares the product name in detail page with checkout page
  expect(offeringPriceInProductDetailPage).toEqual(offeringPriceInCheckOutPage);  
  
  await play.checkOutPage.continueButton.click()
  await play.loginPage.username.fill("deneme17@gmail.com")
  await play.loginPage.btnLogin.click()
  await play.loginPage.password.fill("Murratt_01")
  await play.loginPage.btnLogin.click()

  await play.checkOutPage.otherPaymentOptions.click()
  await play.checkOutPage.instantPayment.click()

  page.close();

});
  
  
 

