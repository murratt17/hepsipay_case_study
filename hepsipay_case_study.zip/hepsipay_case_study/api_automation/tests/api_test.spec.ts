import { test, expect } from '@playwright/test';
import { Category, Pet } from '../sources/pets';
import exp from 'constants';
import { Store } from '../sources/store';



test('getPetId16', async ({ request }) => {
  
  const response = await request.get('https://petstore.swagger.io/v2/pet/16');       
  expect(response.json).not.toBeNull();                                             
  expect(response.status()).toBe(200)                                             
  const text = await response.text()              
  const pet:Pet = JSON.parse(text);   
  let tags = pet.tags                                                               
  expect(pet.name).not.toBeNull                                                    
  expect(pet.id).not.toBeNull                                                   
  expect(pet.status).toEqual('available')
  for(var index in tags){
      expect(tags[index].name).not.toBeNull                                    
      expect(tags[index].id).not.toBeNull                                   

  }
});

test('putPetDoggie', async ({ request }) => {
 
  const response = await request.post('https://petstore.swagger.io/v2/pet',{        

  data :{
    "id": 0,
    "category": {
      "id": 0,
      "name": "string"
    },
    "name": "doggie",
    "photoUrls": [
      "string"
    ],
    "tags": [
      {
        "id": 0,
        "name": "string"
      }
    ],
    "status": "available"
  }
  });

  const text = await response.text()
  expect(response.json).not.toBeNull();                                               
  expect (response.status()).toBe(200)                                                
  const pet:Pet = JSON.parse(text);     
  expect(pet.name).toBe("doggie")     
  expect(pet.status).toBe("available")
  expect(pet.tags[0].name).toBe("string")    
  expect(pet.category?.id).toBe(0)
  expect(pet.category?.name).toBe("string")                                      
      
});

test('deleteNotExistingPetId', async ({ request }) => {
 
  const response = await request.delete('https://petstore.swagger.io/v2/pet/1231113')     //request
  const text = await response.text()
  expect(response.json).not.toBeNull();                                               
  expect(response.status()).toBe(404)                                                 

});


test('getPetsPendingStatus', async ({ request }) => {
  
  const response = await request.get('https://petstore.swagger.io/v2/pet/findByStatus?status=pending');   //request
  expect(response.json).not.toBeNull();                                             
  expect(response.status()).toBe(200)                                               
  const text = await response.text()              
  const pet = JSON.parse(text);  
                                                  
  for(var index in pet){
      expect(pet[index].id).not.toBeNull     
      expect(pet[index].status).toBe("pending")                              
      console.log("index  " + index + " " + pet[index].name)
  }
});


test('getStoreOrder9', async ({ request }) => {
 
  const response = await request.post('https://petstore.swagger.io/v2/store/order',{        //request

  data :{
    "id": 12,
    "petId": 14,
    "quantity": 8,
    "shipDate": "2024-02-27T08:16:00.589Z",
    "status": "placed",
    "complete": true
  }
  });
  
  const text = await response.text()
  expect(response.json).not.toBeNull();                                              
  expect (response.status()).toBe(200)                                              
  const store: Store = JSON.parse(text);     
  expect(store.id).toBe(12)
  expect(store.petId).toBe(14)
  expect(store.quantity).toBe(8)
  expect(store.shipDate).toBe("2024-02-27T08:16:00.589+0000")
  expect(store.status).toBe("placed")
  expect(store.complete).toBe(true)

  
});